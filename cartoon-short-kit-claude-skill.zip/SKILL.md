---
name: cartoon-short-kit
description: Create, plan, animate, render, and finish vertical 2D cartoon-story shorts using the included Three.js/Chromium toolkit. Use when the user wants a cartoon short, animated story video, shot plan, character animation, voiceover timing, sound effects, rendering, or video quality checks.
---

# Cartoon Short Kit

Use this skill to help create a vertical cartoon-story video with the bundled renderer and tools. The intended output is a 1080 × 1920, 30 fps MP4 with a stylized 3D painted environment and illustrated characters.

## What is included

- `engine/`: browser-based Three.js scene renderer, character drawing, paint textures, motion helpers, and HTML entry point.
- `example/soldier/`: a complete example shot plan (`story.js`) and example audio cue generator (`audio.py`). Treat these as examples, not as the user's new story.
- `tools/setup.sh`: creates a project directory and copies starter files into it.
- `tools/timing.py`: aligns spoken words to voiceover timestamps, using Whisper when installed or script-and-silence alignment as a fallback.
- `tools/render.mjs`: renders selected frame ranges through Playwright Chromium.
- `tools/sheet.py`: creates a contact sheet from rendered frames.
- `tools/finish.sh`: mixes/normalizes audio, encodes the MP4, and creates a QA contact sheet.

## Important operating rules

1. First clarify the user's story idea, target duration, language, tone, and whether they already have a script, voiceover, or character references. Do not ask for information they have already provided.
2. Help turn the idea into a concise voiceover script with a strong opening hook, clear visual beats, and a satisfying ending. Keep the story original unless the user requests an adaptation and has rights to the source.
3. Create a shot-by-shot plan in `story.js`. The example uses `FPS = 30`, a `TOTAL` frame count, `SHOTS`, camera keyframes, lighting, and per-frame scene logic. Keep frame numbers consistent with the voiceover duration: approximately `duration_seconds × 30` frames.
4. Treat `example/soldier/story.js` and `example/soldier/audio.py` as templates. Replace the story, shot timings, visual actions, and audio cues for each new project. Do not leave soldier-specific content in a new user's project unless requested.
5. Use `tools/timing.py` to create `words.json` and `phrases.json` from the voiceover and script. Review the generated phrase timings against the audio; automatic alignment can be imperfect and should be manually corrected when needed.
6. Render a small frame range first to catch scene errors before rendering the full video. Then render all required frames, inspect a contact sheet, fix visual problems, and render again as needed.
7. Finish with `tools/finish.sh` and inspect the resulting MP4 and `out/qa_sheet.jpg`. Check framing, readability, continuity, audio levels, black frames, and frozen sections.
8. Never claim that files were rendered, tested, or exported unless the relevant commands actually ran and the output files were verified.

## Setup and dependencies

The toolkit's setup script documents these requirements:

- Node.js 22.6 or newer (for built-in TypeScript type stripping used by setup).
- Python 3.
- `numpy` for the example audio generator; `Pillow` for contact sheets.
- `ffmpeg` and `ffprobe`.
- Git and npm for fetching dependencies.
- Playwright with Chromium available to Node.js.
- Network access during setup to obtain Three.js and the upstream toon/character helper.

The setup script may download code from external repositories and create files in the chosen project directory. Explain this before asking the user to run it. Do not execute downloaded scripts or install dependencies without the user's permission. If a dependency or command is unavailable, explain the blocker and offer the next step rather than pretending setup succeeded.

## Typical workflow

From the directory containing this skill's `tools/` and `engine/` folders:

```bash
bash tools/setup.sh ~/shorts/my-short
cd ~/shorts/my-short
```

Add the user's voiceover as `voice.mp3` and their script as `script.txt`, then run:

```bash
python3 timing.py voice.mp3 script.txt --out work
```

Edit `web/story.js` for the new scene plan and character actions. Edit `audio.py` for the new sound/music cue plan; the included file is only the soldier example. After setting up the scene and required assets, render a test range and then the full frame range, for example:

```bash
node render.mjs frames 0-89
python3 sheet.py frames out/contact-sheet.jpg
```

Render commands depend on the project's `web/` scene being complete. Once all frames and the mixed audio (`mix_raw.wav`) exist, run:

```bash
bash finish.sh "My Short Title"
```

The finished video is written under `out/`. Adjust paths and commands to match the actual project. Do not assume the example's 592-frame duration applies to a new story.

## How to help the user

- If the user only has an idea: write the narration and a visual beat list first.
- If the user has narration but no voiceover: help prepare a clean recording script and timing plan.
- If the user has a voiceover: help align the script to it and plan shots around the actual duration.
- If the user wants a new story: update the example shot plan conceptually; do not merely rename the soldier story.
- If the user is not technical: give one action at a time, explain where to put each file, and avoid dumping a long list of terminal commands without context.
- If the user asks for help debugging: request the exact error and relevant file/output, inspect it, and suggest the smallest safe fix.

## File integrity

Keep the bundled engine and tools intact unless a change is required for the user's project. When modifying code, explain what changed and preserve a copy of the original where practical. Do not remove the example, because it demonstrates how the renderer is structured.
